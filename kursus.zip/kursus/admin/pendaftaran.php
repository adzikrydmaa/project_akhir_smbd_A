<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";
$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Tambah pendaftaran
if (isset($_POST['tambah'])) {
    $id_peserta = $_POST['id_peserta'];
    $id_kursus = $_POST['id_kursus'];
    $tanggal = $_POST['tanggal_daftar'];

    $query = "INSERT INTO pendaftaran (id_peserta, id_kursus, tanggal_daftar) 
              VALUES ('$id_peserta', '$id_kursus', '$tanggal')";
    if (mysqli_query($conn, $query)) {
        header("Location: pendaftaran.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Pendaftaran Kursus</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- AdminLTE & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

  <style>
    :root {
      --pink-main: rgb(66, 39, 109);
      --pink-hover: rgb(55, 30, 90);
    }
    .btn-pink { background-color: var(--pink-main); color: #fff; border: none; }
    .btn-pink:hover { background-color: var(--pink-hover); }
    .nav-sidebar .nav-link.active { background: rgb(255,154,65); color:#fff !important; }
    .nav-sidebar .nav-item:hover > .nav-link { background: rgb(255,154,65); color:#fff !important; }
    .sidebar::-webkit-scrollbar-thumb { background: rgb(255,154,65); }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color: var(--pink-main);"></i></a>
      </li>
    </ul>
  </nav>

  <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color: var(--pink-main);">
    <a href="#" class="brand-link text-center">
      <span style="color:#fff;font-weight:bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column">
          <li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="nav-icon fas fa-tachometer-alt" style="color:#fff;"></i><p>Dashboard</p></a></li>
          <li class="nav-item"><a href="instruktur.php" class="nav-link"><i class="nav-icon fas fa-user-tie" style="color:#fff;"></i><p>Instruktur</p></a></li>
          <li class="nav-item"><a href="peserta.php" class="nav-link"><i class="nav-icon fas fa-users" style="color:#fff;"></i><p>Peserta</p></a></li>
          <li class="nav-item"><a href="kursus.php" class="nav-link"><i class="nav-icon fas fa-book-open" style="color:#fff;"></i><p>Kursus</p></a></li>
          <li class="nav-item"><a href="pendaftaran.php" class="nav-link active"><i class="nav-icon fas fa-file-signature" style="color:#fff;"></i><p>Pendaftaran</p></a></li>
          <li class="nav-item"><a href="pembayaran.php" class="nav-link"><i class="nav-icon fas fa-money-bill-wave" style="color:#fff;"></i><p>Pembayaran</p></a></li>
          <li class="nav-item"><a href="sertifikat.php" class="nav-link"><i class="nav-icon fas fa-certificate" style="color:#fff;"></i><p>Sertifikat</p></a></li>
          <li class="nav-item"><a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fas fa-sign-out-alt mr-2"></i><p>Logout</p></a>

        </ul>
      </nav>
    </div>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <h1 class="m-0 text-dark">Pendaftaran Kursus</h1>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">

        <!-- Form -->
        <div class="card mb-4" style="border-top: 3px solid rgb(66, 39, 109);">
          <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
            <h3 class="card-title text-white">Form Tambah Pendaftaran</h3>
          </div>
          <div class="card-body">
            <form method="POST">
              <div class="form-row">
                <div class="form-group col-md-4">
                  <label>Peserta</label>
                  <select name="id_peserta" class="form-control" required>
                    <option value="">Pilih Peserta</option>
                    <?php
                    $peserta_q = mysqli_query($conn, "SELECT * FROM peserta");
                    while ($ps = mysqli_fetch_assoc($peserta_q)) {
                        echo "<option value='{$ps['id_peserta']}'>{$ps['nama_peserta']}</option>";
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group col-md-4">
                  <label>Kursus</label>
                  <select name="id_kursus" class="form-control" required>
                    <option value="">Pilih Kursus</option>
                    <?php
                    $kursus_q = mysqli_query($conn, "SELECT * FROM kursus");
                    while ($k = mysqli_fetch_assoc($kursus_q)) {
                        echo "<option value='{$k['id_kursus']}'>{$k['nama_kursus']}</option>";
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group col-md-4">
                  <label>Tanggal Daftar</label>
                  <input type="date" name="tanggal_daftar" class="form-control" required>
                </div>
              </div>
              <button type="submit" name="tambah" class="btn btn-pink">Tambah</button>
            </form>
          </div>
        </div>

        <!-- // Tabel Pendaftaran// -->
        <div class="card" style="border-top: 3px solid var(--pink-main);">
          <div class="card-header">
            <h3 class="card-title">Data Pendaftaran</h3>
          </div>
          <div class="card-body">
            <table class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Peserta</th>
                  <th>Nama Kursus</th>
                  <th>Tanggal Daftar</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                $query = mysqli_query($conn, "SELECT p.id_pendaftaran, ps.nama_peserta, k.nama_kursus, p.tanggal_daftar 
                  FROM pendaftaran p
                  JOIN peserta ps ON p.id_peserta = ps.id_peserta
                  JOIN kursus k ON p.id_kursus = k.id_kursus");
                while ($data = mysqli_fetch_assoc($query)) {
                ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= htmlspecialchars($data['nama_peserta']) ?></td>
                  <td><?= htmlspecialchars($data['nama_kursus']) ?></td>
                  <td><?= $data['tanggal_daftar'] ?></td>
                  <td>
                    <a href='edit_pendaftaran.php?id=<?= $data['id_pendaftaran'] ?>' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='hapus_pendaftaran.php?id=<?= $data['id_pendaftaran'] ?>' onclick='return confirm("Yakin hapus?")' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="main-footer text-center">
    <strong>© 2025 Sistem Kursus</strong>
  </footer>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
