<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$instruktur_result = mysqli_query($conn, "SELECT * FROM instruktur");
$kursus_result = mysqli_query($conn, "SELECT * FROM kursus");

if (isset($_POST['simpan'])) {
    $id_pendaftaran = intval($_POST['id_pendaftaran']);
    $jumlah = floatval($_POST['jumlah']);
    $tanggal_bayar = mysqli_real_escape_string($conn, $_POST['tanggal_bayar']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    if ($jumlah <= 0) {
        echo "<script>alert('Jumlah pembayaran harus lebih dari 0!'); window.location='pembayaran.php';</script>";
        exit;
    }

    $query = "INSERT INTO pembayaran (id_pendaftaran, jumlah, tanggal_bayar, STATUS)
              VALUES ($id_pendaftaran, $jumlah, '$tanggal_bayar', '$status')";
    mysqli_query($conn, $query) or die(mysqli_error($conn));
    header("Location: pembayaran.php");
    exit;
}


$pendaftaran_result = mysqli_query($conn, "
    SELECT p.id_pendaftaran, ps.nama_peserta 
    FROM pendaftaran p 
    JOIN peserta ps ON p.id_peserta = ps.id_peserta");

// List Pembayaran
$pembayaran_result = mysqli_query($conn, "
    SELECT bayar.id_pembayaran, bayar.jumlah, bayar.tanggal_bayar, bayar.STATUS,
           p.id_pendaftaran, ps.nama_peserta
    FROM pembayaran bayar
    JOIN pendaftaran p ON bayar.id_pendaftaran = p.id_pendaftaran
    JOIN peserta ps ON p.id_peserta = ps.id_peserta
    ORDER BY bayar.tanggal_bayar DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Pembayaran</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- AdminLTE & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

  <style>
    .btn-pink {
      background-color: rgb(66, 39, 109);
      color: white;
      border: none;
    }
    .btn-pink:hover {
      background-color: rgb(66, 39, 109);
    }
    .nav-sidebar .nav-link.active {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .nav-sidebar .nav-item:hover > .nav-link {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .sidebar::-webkit-scrollbar-thumb {
      background-color: rgb(66, 39, 109);
    }
    .input-group-text {
      background-color: rgb(66, 39, 109);
      color: white;
      border: none;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini"></body>
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color:rgb(66, 39, 109);"></i></a>
      </li>
    </ul>
  </nav>
  <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color: #fff; font-weight: bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt" style="color: white;"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="instruktur.php" class="nav-link">
              <i class="nav-icon fas fa-user-tie" style="color: white;"></i>
              <p>Instruktur</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="peserta.php" class="nav-link">
              <i class="nav-icon fas fa-users" style="color: white;"></i>
              <p>Peserta</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="kursus.php" class="nav-link">
              <i class="nav-icon fas fa-book-open" style="color: white;"></i>
              <p>Kursus</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pendaftaran.php" class="nav-link">
              <i class="nav-icon fas fa-file-signature" style="color: white;"></i>
              <p>Pendaftaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pembayaran.php" class="nav-link active">
              <i class="nav-icon fas fa-money-bill-wave" style="color: white;"></i>
              <p>Pembayaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="sertifikat.php" class="nav-link">
              <i class="nav-icon fas fa-certificate" style="color: white;"></i>
              <p>Sertifikat</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')">
              <i class="fas fa-sign-out-alt mr-2"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>
<!-- Content Wrapper -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <h1 class="m-0">Pembayaran</h1>
    </div>
  </div>
  <div class="content">
    <div class="container-fluid">
      <!-- Form Tambah -->
      <div class="card border-top border-pink">
        <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
          <h3 class="card-title text-white">Tambah Pembayaran</h3>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="row">
              <div class="col-md-4">
                <label>ID Pendaftaran</label>
                <select name="id_pendaftaran" class="form-control" required>
                  <option value="">-- Pilih Pendaftaran --</option>
                  <?php while ($row = mysqli_fetch_assoc($pendaftaran_result)): ?>
                    <option value="<?= $row['id_pendaftaran'] ?>">
                      ID <?= $row['id_pendaftaran'] ?> - <?= htmlspecialchars($row['nama_peserta']) ?>
                    </option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="col-md-3">
                <label>Jumlah (Rp)</label>
                <input type="number" step="0.01" name="jumlah" class="form-control" required />
              </div>
              <div class="col-md-3">
                <label>Tanggal Bayar</label>
                <input type="date" name="tanggal_bayar" class="form-control" required />
              </div>
              <div class="col-md-2">
                <label>Status</label>
                <select name="status" class="form-control" required>
                  <option value="Belum Lunas">Belum Lunas</option>
                  <option value="Lunas">Lunas</option>
                </select>
              </div>
            </div>
            <div class="mt-3">
              <button type="submit" name="simpan" class="btn btn-pink">Simpan</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Tabel Pembayaran -->
      <div class="card mb-4" style="border-top: 3px solid rgb(66, 39, 109);">
          <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
            <h3 class="card-title text-white">Daftar Pembayaran</h3>
        </div>
        <div class="card-body table-responsive p-0" style="max-height: 400px;">
          <table class="table table-bordered table-striped table-hover text-nowrap">
            <thead class="text-white" style="background-color: rgb(66, 39, 109);">
              <tr>
                <th>No</th>
                <th>ID Pembayaran</th>
                <th>Nama Peserta</th>
                <th>ID Pendaftaran</th>
                <th>Jumlah (Rp)</th>
                <th>Tanggal Bayar</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; while ($row = mysqli_fetch_assoc($pembayaran_result)): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= $row['id_pembayaran'] ?></td>
                <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                <td><?= $row['id_pendaftaran'] ?></td>
                <td><?= number_format($row['jumlah'], 2, ',', '.') ?></td>
                <td><?= $row['tanggal_bayar'] ?></td>
                <td><?= $row['STATUS'] ?></td>
                <td>
                  <a href="edit_pembayaran.php?id=<?= $row['id_pembayaran'] ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="hapus_pembayaran.php?id=<?= $row['id_pembayaran'] ?>" onclick="return confirm('Yakin hapus?')" class="btn btn-danger btn-sm">Hapus</a>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>
<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
  // Isi modal detail ketika modal ditampilkan
  $('#detailModal').on('show.bs.modal', function (event) {
    const button = $(event.relatedTarget);
    const nama = button.data('nama');
    const deskripsi = button.data('deskripsi');
    const harga = button.data('harga');

    const modal = $(this);
    modal.find('#modalKursusNama').text(nama);
    modal.find('#modalKursusDeskripsi').text(deskripsi);
    modal.find('#modalKursusHarga').text(harga);
  });
</script>

</body>
</html>