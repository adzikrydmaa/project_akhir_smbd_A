<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data pembayaran berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // hindari SQL Injection
    $query = "SELECT * FROM pembayaran WHERE id_pembayaran = $id";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        echo "Data pembayaran tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak ditemukan.";
    exit;
}

// Simpan perubahan jika form disubmit
if (isset($_POST['update'])) {
    $id_pendaftaran = intval($_POST['id_pendaftaran']);
    $jumlah = floatval($_POST['jumlah']);
    $tanggal_bayar = $_POST['tanggal_bayar'];
    $status = $_POST['status'];

    $query = "CALL edit_pembayaran('$id', '$id_pendaftaran', '$jumlah', '$tanggal_bayar', '$status')";
    mysqli_query($conn, $query);

    header("Location: pembayaran.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pembayaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color:rgb(66, 39, 109);
        }
        .btn-pink {
            background-color:rgb(66, 39, 109);
            color: white;
        }
        .btn-pink:hover {
            background-color:rgb(66, 39, 109);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Pembayaran</h3>
        <form method="POST">
            <div class="form-group">
                <label>ID Pendaftaran</label>
                <select name="id_pendaftaran" class="form-control" required>
                    <option value="">-- Pilih Pendaftaran --</option>
                    <?php
                    $pendaftaran_query = "SELECT p.id_pendaftaran, ps.nama_peserta 
                                          FROM pendaftaran p 
                                          JOIN peserta ps ON p.id_peserta = ps.id_peserta";
                    $pendaftaran_result = mysqli_query($conn, $pendaftaran_query);
                    while ($row = mysqli_fetch_assoc($pendaftaran_result)) {
                        $selected = ($row['id_pendaftaran'] == $data['id_pendaftaran']) ? 'selected' : '';
                        echo "<option value='{$row['id_pendaftaran']}' $selected>ID {$row['id_pendaftaran']} - {$row['nama_peserta']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Jumlah (Rp)</label>
                <input type="number" step="0.01" name="jumlah" class="form-control" value="<?php echo $data['jumlah']; ?>" required>
            </div>
            <div class="form-group">
                <label>Tanggal Bayar</label>
                <input type="date" name="tanggal_bayar" class="form-control" value="<?php echo $data['tanggal_bayar']; ?>" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control" required>
                    <option value="Belum Lunas" <?php if($data['STATUS'] == 'Belum Lunas') echo 'selected'; ?>>Belum Lunas</option>
                    <option value="Lunas" <?php if($data['STATUS'] == 'Lunas') echo 'selected'; ?>>Lunas</option>
                </select>
            </div>
            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="pembayaran.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
