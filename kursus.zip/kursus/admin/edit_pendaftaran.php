<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data pendaftaran berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM pendaftaran WHERE id_pendaftaran = $id";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        echo "Data pendaftaran tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak ditemukan.";
    exit;
}

// Proses simpan perubahan jika form disubmit
if (isset($_POST['update'])) {
    $id_peserta = intval($_POST['id_peserta']);
    $id_kursus = intval($_POST['id_kursus']);
    $tanggal_daftar = $_POST['tanggal_daftar'];

    $query = "UPDATE pendaftaran 
              SET id_peserta = $id_peserta,
                  id_kursus = $id_kursus,
                  tanggal_daftar = '$tanggal_daftar'
              WHERE id_pendaftaran = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: pendaftaran.php");
        exit;
    } else {
        echo "Error saat update data: " . mysqli_error($conn);
    }
}

// Ambil data peserta dan kursus untuk dropdown
$peserta_result = mysqli_query($conn, "SELECT * FROM peserta");
$kursus_result = mysqli_query($conn, "SELECT * FROM kursus");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pendaftaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ffe6f0;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff4da6;
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
        label {
            font-weight: 600;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Pendaftaran</h3>
        <form method="POST">
            <div class="form-group">
                <label>Peserta</label>
                <select name="id_peserta" class="form-control" required>
                    <option value="">-- Pilih Peserta --</option>
                    <?php while ($row = mysqli_fetch_assoc($peserta_result)): ?>
                        <option value="<?= $row['id_peserta'] ?>" <?= $row['id_peserta'] == $data['id_peserta'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['nama_peserta']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Kursus</label>
                <select name="id_kursus" class="form-control" required>
                    <option value="">-- Pilih Kursus --</option>
                    <?php while ($row = mysqli_fetch_assoc($kursus_result)): ?>
                        <option value="<?= $row['id_kursus'] ?>" <?= $row['id_kursus'] == $data['id_kursus'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['nama_kursus']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tanggal Daftar</label>
                <input type="date" name="tanggal_daftar" class="form-control" value="<?= $data['tanggal_daftar'] ?>" required>
            </div>
            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="pendaftaran.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>