<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data instruktur berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // hindari SQL Injection
    $query = "SELECT * FROM instruktur WHERE id_instruktur = $id";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        echo "Data instruktur tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak ditemukan.";
    exit;
}

// Simpan perubahan jika form disubmit
if (isset($_POST['update'])) {
    $nama = $_POST['nama_instruktur'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $keahlian = $_POST['keahlian'];

    $query = "UPDATE instruktur 
              SET nama_instruktur='$nama', email='$email', no_hp='$no_hp', keahlian='$keahlian' 
              WHERE id_instruktur=$id";
    mysqli_query($conn, $query);
    header("Location: instruktur.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Instruktur</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ffe6f0;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff4da6;
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Instruktur</h3>
        <form method="POST">
            <div class="form-group">
                <label>Nama Instruktur</label>
                <input type="text" name="nama_instruktur" class="form-control" value="<?php echo $data['nama_instruktur']; ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo $data['email']; ?>" required>
            </div>
            <div class="form-group">
                <label>No HP</label>
                <input type="text" name="no_hp" class="form-control" value="<?php echo $data['no_hp']; ?>" required>
            </div>
            <div class="form-group">
                <label>Keahlian</label>
                <input type="text" name="keahlian" class="form-control" value="<?php echo $data['keahlian']; ?>" required>
            </div>
            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="instruktur.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
