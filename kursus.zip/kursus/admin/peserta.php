
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_peserta'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    $query = "CALL sp_tambah_peserta(?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $nama, $email, $no_hp, $alamat);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal menambahkan peserta: " . mysqli_error($conn) . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Gagal mempersiapkan statement: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Peserta</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- AdminLTE & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <style>
    .btn-pink {
      background-color: rgb(66, 39, 109);
      color: white;
      border: none;
    }
    .btn-pink:hover {
      background-color: rgb(66, 39, 109);
    }
    .nav-sidebar .nav-link.active {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .nav-sidebar .nav-item:hover > .nav-link {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .sidebar::-webkit-scrollbar-thumb {
      background-color: rgb(66, 39, 109);
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color:rgb(66, 39, 109);"></i></a>
      </li>
    </ul>
  </nav>

  <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color: #fff; font-weight: bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt" style="color: white;"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="instruktur.php" class="nav-link">
              <i class="nav-icon fas fa-user-tie" style="color: white;"></i>
              <p>Instruktur</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="peserta.php" class="nav-link active">
              <i class="nav-icon fas fa-users" style="color: white;"></i>
              <p>Peserta</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="kursus.php" class="nav-link">
              <i class="nav-icon fas fa-book-open" style="color: white;"></i>
              <p>Kursus</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pendaftaran.php" class="nav-link">
              <i class="nav-icon fas fa-file-signature" style="color: white;"></i>
              <p>Pendaftaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pembayaran.php" class="nav-link">
              <i class="nav-icon fas fa-money-bill-wave" style="color: white;"></i>
              <p>Pembayaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="sertifikat.php" class="nav-link">
              <i class="nav-icon fas fa-certificate" style="color: white;"></i>
              <p>Sertifikat</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')">
              <i class="fas fa-sign-out-alt mr-2"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- Content Wrapper -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <h1 class="m-0 text-dark">Manajemen Peserta</h1>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">
        <!-- Form Tambah -->
        <div class="card" style="border-top: 3px solid rgb(66, 39, 109);">
          <div class="card-header"style="background-color:rgb(66, 39, 109);">
            <h3 class="card-title text-white">Tambah Peserta</h3>
          </div>
          <div class="card-body">
            <form method="POST">
              <div class="row">
                <div class="col-md-3">
                  <label>Nama Peserta</label>
                  <input type="text" name="nama_peserta" class="form-control" required>
                </div>
                <div class="col-md-3">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" required>
                </div>
                <div class="col-md-3">
                  <label>No HP</label>
                  <input type="text" name="no_hp" class="form-control" required>
                </div>
                <div class="col-md-3">
                  <label>Alamat</label>
                  <input type="text" name="alamat" class="form-control" required>
                </div>
              </div>
              <div class="mt-3">
                <button type="submit" name="simpan" class="btn btn-pink">
                  <i class="fas fa-plus"></i> Simpan
                </button>
              </div>
            </form>
          </div>
        </div>

        <!-- Tabel -->
        <div class="card border-top border-pink">
        <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
          <h3 class="card-title text-white">Daftar Peserta</h3>
          </div>
          <div class="card-body">
            <table class="table table-bordered table-striped">
              <thead style="background-color: rgb(66, 39, 109); color: white;">
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>No HP</th>
                  <th>Alamat</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                $result = mysqli_query($conn, "SELECT * FROM peserta");
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>
                          <td>{$no}</td>
                          <td>{$row['nama_peserta']}</td>
                          <td>{$row['email']}</td>
                          <td>{$row['no_hp']}</td>
                          <td>{$row['alamat']}</td>
                          <td>
                            <a href='edit_peserta.php?id={$row['id_peserta']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='hapus_peserta.php?id={$row['id_peserta']}' onclick='return confirm(\"Yakin hapus?\")' class='btn btn-danger btn-sm'>Hapus</a>
                          </td>
                        </tr>";
                  $no++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="main-footer text-center">
    <strong>© 2025 Sistem Kursus</strong>
  </footer>
</div>

<!-- Script -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
