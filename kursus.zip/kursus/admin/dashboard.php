<?php
include '../koneksi.php';

// Query kursus
$query_kursus = "SELECT k.id_kursus, k.nama_kursus, k.harga, k.durasi, i.nama_instruktur 
          FROM kursus k JOIN instruktur i ON k.id_instruktur = i.id_instruktur";
$result_kursus = mysqli_query($conn, $query_kursus);
if (!$result_kursus) {
    die("Query error kursus: " . mysqli_error($conn));
}
// Query pendaftaran lengkap dari view
$query_pendaftaran = "SELECT * FROM view_pendaftaran_lengkap ORDER BY tanggal_daftar DESC";
$result_pendaftaran = mysqli_query($conn, $query_pendaftaran);
if (!$result_pendaftaran) {
    die("Query error pendaftaran: " . mysqli_error($conn));
}
// Query Pembayaran Peserta dari view
$query_pembayaran_peserta = "SELECT * FROM view_pembayaran_peserta ";
$result_pembayaran_peserta = mysqli_query($conn, "SELECT * FROM view_pembayaran_peserta");

if (!$result_pembayaran_peserta) {
    die("Query error pembayaran_peserta: " . mysqli_error($conn));
}
// Query jumlah peserta per kursus dari view
$query_jumlah_peserta = "SELECT k.id_kursus, k.nama_kursus, COUNT(p.id_pendaftaran) AS jumlah_peserta FROM kursus k LEFT JOIN 
    pendaftaran p ON k.id_kursus = p.id_kursus GROUP BY k.id_kursus, k.nama_kursus";
$result_jumlah_peserta = mysqli_query($conn, $query_jumlah_peserta);

if (!$result_jumlah_peserta) {
    die("Query error jumlah_peserta: " . mysqli_error($conn));
}
// Query kursus_populer dari view
$query_kursus_populer = "SELECT * FROM view_kursus_populer";
$result_kursus_populer = mysqli_query($conn, $query_kursus_populer);

if (!$result_kursus_populer) {
    die("Query error kursus_populer: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Kursus</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root {
      --pink-main: rgb(66, 39, 109);
      --pink-hover: rgb(66, 39, 109);
    }
    .btn-pink { background: var(--pink-main); color:#fff; border:none; }
    .btn-pink:hover { background: var(--pink-hover); }
    .nav-sidebar .nav-link.active { background: rgb(255,154,65); color:#fff !important; }
    .nav-sidebar .nav-item:hover > .nav-link { background: rgb(255,154,65); color:#fff !important; }
    .sidebar::-webkit-scrollbar-thumb { background: rgb(255,154,65); }
    .card-clickable { cursor: pointer; transition: all 0.2s ease-in-out; }
    .card-clickable:hover { box-shadow: 0 4px 10px rgba(0,0,0,0.1); transform: scale(1.01); }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color:rgb(66, 39, 109);"></i></a>
      </li>
    </ul>
  </nav>

  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color: #fff; font-weight: bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt mr-2"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="instruktur.php" class="nav-link">
              <i class="nav-icon fas fa-user-tie mr-2"></i>
              <p>Instruktur</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="peserta.php" class="nav-link">
              <i class="nav-icon fas fa-users mr-2"></i>
              <p>Peserta</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="kursus.php" class="nav-link">
              <i class="nav-icon fas fa-book-open mr-2"></i>
              <p>Kursus</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pendaftaran.php" class="nav-link">
              <i class="nav-icon fas fa-file-signature mr-2"></i>
              <p>Pendaftaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pembayaran.php" class="nav-link">
              <i class="nav-icon fas fa-money-bill-wave mr-2"></i>
              <p>Pembayaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="sertifikat.php" class="nav-link">
              <i class="nav-icon fas fa-certificate mr-2"></i>
              <p>Sertifikat</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')">
              <i class="fas fa-sign-out-alt mr-2"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>

  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid text-center mb-3">
        <h1 class="m-0 text-dark">Dashboard Kursus</h1>
        <img src="https://img.freepik.com/free-vector/online-tutorials-concept_52683-37480.jpg" alt="Dashboard Banner" class="img-fluid rounded mt-2" style="max-height: 200px; object-fit: cover;">
      </div>
  </div>
    <div class="content">
      <div class="container-fluid">

        <!-- Card Kursus -->
        <div class="card card-clickable" data-toggle="collapse" href="#collapseKursus" role="button" aria-expanded="false" aria-controls="collapseKursus" style="border-top: 3px solid rgb(212, 170, 30);">
          <div class="card-header">
            <h3 class="card-title">Kursus</h3>
          </div>
        </div>
        <div class="collapse mt-2" id="collapseKursus">
          <div class="card card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>ID Kursus</th>
                    <th>Nama Kursus</th>
                    <th>Harga</th>
                    <th>Durasi (jam)</th>
                    <th>Instruktur</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = mysqli_fetch_assoc($result_kursus)): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['id_kursus']) ?></td>
                      <td><?= htmlspecialchars($row['nama_kursus']) ?></td>
                      <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
                      <td><?= htmlspecialchars($row['durasi']) ?></td>
                      <td><?= htmlspecialchars($row['nama_instruktur']) ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Card Pendaftaran Lengkap -->
        <div class="card card-clickable mt-4" data-toggle="collapse" href="#collapsePendaftaran" role="button" aria-expanded="false" aria-controls="collapsePendaftaran" style="border-top: 3px solid rgb(212, 170, 30);">
          <div class="card-header">
            <h3 class="card-title">Pendaftaran Lengkap</h3>
          </div>
        </div>
        <div class="collapse mt-2" id="collapsePendaftaran">
          <div class="card card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>ID Pendaftaran</th>
                    <th>Nama Peserta</th>
                    <th>Email</th>
                    <th>Nama Kursus</th>
                    <th>Durasi (jam)</th>
                    <th>Harga</th>
                    <th>Nama Instruktur</th>
                    <th>Tanggal Daftar</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = mysqli_fetch_assoc($result_pendaftaran)): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['id_pendaftaran']) ?></td>
                      <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                      <td><?= htmlspecialchars($row['email']) ?></td>
                      <td><?= htmlspecialchars($row['nama_kursus']) ?></td>
                      <td><?= htmlspecialchars($row['durasi']) ?></td>
                      <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
                      <td><?= htmlspecialchars($row['nama_instruktur']) ?></td>
                      <td><?= htmlspecialchars($row['tanggal_daftar']) ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
                <!-- Card Pembayaran Peserta -->
        <div class="card card-clickable mt-4" data-toggle="collapse" href="#collapsePembayaran" role="button" aria-expanded="false" aria-controls="collapsePembayaran" style="border-top: 3px solid rgb(212, 170, 30) ;">
          <div class="card-header">
            <h3 class="card-title">Pembayaran Peserta</h3>
          </div>
        </div>
        <div class="collapse mt-2" id="collapsePembayaran">
          <div class="card card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Nama Peserta</th>
                    <th>Nama Kursus</th>
                    <th>Jumlah</th>
                    <th>Tanggal Bayar</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = mysqli_fetch_assoc($result_pembayaran_peserta)): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                      <td><?= htmlspecialchars($row['nama_kursus']) ?></td>
                      <td><?= htmlspecialchars($row['jumlah']) ?></td>
                      <td><?= htmlspecialchars($row['tanggal_bayar']) ?></td>
                      <td><?= htmlspecialchars($row['status']) ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
            <!-- Card Jumlah Peserta per Kursus -->
            <div class="card card-clickable mt-4" data-toggle="collapse" href="#collapseJumlahPeserta" role="button" aria-expanded="false" aria-controls="collapseJumlahPeserta" style="border-top: 3px solid #d4aa1e;">
              <div class="card-header">
                <h3 class="card-title">Jumlah Peserta per Kursus</h3>
              </div>
            </div>
            <div class="collapse mt-2" id="collapseJumlahPeserta">
              <div class="card card-body">
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>ID Kursus</th>
                      <th>Nama Kursus</th>
                      <th>Jumlah Peserta</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result_jumlah_peserta)): ?>
                    <tr>
                      <td><?= htmlspecialchars($row['id_kursus']) ?></td>
                      <td><?= htmlspecialchars($row['nama_kursus']) ?></td>
                      <td><?= htmlspecialchars($row['jumlah_peserta']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            </div>
          <!-- Card Kursus Populer-->
          <div class="card card-clickable mt-4" data-toggle="collapse" href="#collapseKursusPopuler" role="button" aria-expanded="false" aria-controls="collapseKursusPopuler" style="border-top: 3px solid #d4aa1e;">
            <div class="card-header">
              <h3 class="card-title">Kursus Populer</h3>
            </div>
          </div>
          <div class="collapse mt-2" id="collapseKursusPopuler">
            <div class="card card-body">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>ID Kursus</th>
                    <th>Nama Kursus</th>
                    <th>Total_Pendaftar</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = mysqli_fetch_assoc($result_kursus_populer)): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['id_kursus']) ?></td>
                    <td><?= htmlspecialchars($row['nama_kursus']) ?></td>
                    <td><?= htmlspecialchars($row['total_pendaftar']) ?></td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
      </div>
    </div>
  </div>

  <footer class="main-footer text-center">
    <strong>© 2025 Sistem Kursus</strong>
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
