<?php
$conn = new mysqli("localhost", "root", "", "kursusku");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // 1. Hapus sertifikat terlebih dahulu
    $stmt1 = $conn->prepare("DELETE FROM sertifikat WHERE id_pendaftaran = ?");
    $stmt1->bind_param("i", $id);
    $stmt1->execute();
    $stmt1->close();

    // 2. Hapus pembayaran (jika ada)
    $stmt2 = $conn->prepare("DELETE FROM pembayaran WHERE id_pendaftaran = ?");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $stmt2->close();

    // 3. Baru hapus pendaftaran
    $stmt3 = $conn->prepare("DELETE FROM pendaftaran WHERE id_pendaftaran = ?");
    $stmt3->bind_param("i", $id);
    if ($stmt3->execute()) {
        header("Location: pendaftaran.php?msg=hapus_sukses");
    } else {
        echo "Gagal menghapus pendaftaran: " . $conn->error;
    }
    $stmt3->close();

} else {
    echo "ID tidak ditemukan.";
}

$conn->close();
?>
