<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data sertifikat berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // hindari SQL Injection
    $query = "SELECT * FROM sertifikat WHERE id_sertifikat = $id";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        echo "Data sertifikat tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak ditemukan.";
    exit;
}

// Proses simpan perubahan jika form disubmit
if (isset($_POST['update'])) {
    $id_pendaftaran = intval($_POST['id_pendaftaran']);
    $nomor_sertifikat = mysqli_real_escape_string($conn, $_POST['nomor_sertifikat']);
    $tanggal_terbit = $_POST['tanggal_terbit'];

    // Cek apakah ada file baru yang diupload
    if (isset($_FILES['file_sertifikat']) && $_FILES['file_sertifikat']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/sertifikat/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Hapus file lama jika ada
        if ($data['file_sertifikat'] && file_exists($data['file_sertifikat'])) {
            unlink($data['file_sertifikat']);
        }

        $fileName = basename($_FILES['file_sertifikat']['name']);
        $targetFile = $uploadDir . time() . '_' . $fileName;

        if (move_uploaded_file($_FILES['file_sertifikat']['tmp_name'], $targetFile)) {
            $file_sertifikat = $targetFile;
        } else {
            echo "Gagal mengupload file sertifikat.";
            exit;
        }
    } else {
        // Jika tidak upload file baru, tetap pakai file lama
        $file_sertifikat = $data['file_sertifikat'];
    }

    // Update data ke database
    $query = "UPDATE sertifikat 
              SET id_pendaftaran = $id_pendaftaran,
                  nomor_sertifikat = '$nomor_sertifikat',
                  tanggal_terbit = '$tanggal_terbit',
                  file_sertifikat = '$file_sertifikat'
              WHERE id_sertifikat = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: sertifikat.php");
        exit;
    } else {
        echo "Error saat update data: " . mysqli_error($conn);
    }
}

// Ambil data pendaftaran untuk dropdown (supaya bisa pilih peserta)
$pendaftaran_query = "SELECT p.id_pendaftaran, ps.nama_peserta 
                      FROM pendaftaran p 
                      JOIN peserta ps ON p.id_peserta = ps.id_peserta";
$pendaftaran_result = mysqli_query($conn, $pendaftaran_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Sertifikat</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ffe6f0;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff4da6;
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
        label {
            font-weight: 600;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Sertifikat</h3>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>ID Pendaftaran</label>
                <select name="id_pendaftaran" class="form-control" required>
                    <option value="">-- Pilih Pendaftaran --</option>
                    <?php while ($row = mysqli_fetch_assoc($pendaftaran_result)): ?>
                        <option value="<?= $row['id_pendaftaran'] ?>" <?= $row['id_pendaftaran'] == $data['id_pendaftaran'] ? 'selected' : '' ?>>
                            ID <?= $row['id_pendaftaran'] ?> - <?= htmlspecialchars($row['nama_peserta']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Nomor Sertifikat</label>
                <input type="text" name="nomor_sertifikat" class="form-control" value="<?= htmlspecialchars($data['nomor_sertifikat']) ?>" required>
            </div>
            <div class="form-group">
                <label>Tanggal Terbit</label>
                <input type="date" name="tanggal_terbit" class="form-control" value="<?= $data['tanggal_terbit'] ?>" required>
            </div>
            <div class="form-group">
                <label>File Sertifikat (PDF/JPG/PNG) - Biarkan kosong jika tidak ingin ganti</label><br>
                <?php if ($data['file_sertifikat'] && file_exists($data['file_sertifikat'])): ?>
                    <a href="<?= $data['file_sertifikat'] ?>" target="_blank">Lihat File Saat Ini</a><br><br>
                <?php endif; ?>
                <input type="file" name="file_sertifikat" accept=".pdf,.jpg,.jpeg,.png" class="form-control-file" />
            </div>
            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="sertifikat.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
