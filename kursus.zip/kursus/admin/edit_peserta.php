<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data peserta berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM peserta WHERE id_peserta = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if (!$data) {
        echo "Data peserta tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak ditemukan.";
    exit;
}

// Simpan perubahan jika form disubmit
if (isset($_POST['update'])) {
    $nama = $_POST['nama_peserta'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    $stmt = $conn->prepare("UPDATE peserta SET nama_peserta=?, email=?, no_hp=?, alamat=? WHERE id_peserta=?");
    $stmt->bind_param("ssssi", $nama, $email, $no_hp, $alamat, $id);
    $stmt->execute();

    header("Location: peserta.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Peserta</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ffe6f0;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff4da6;
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Peserta</h3>
        <form method="POST">
            <div class="form-group">
                <label>Nama Peserta</label>
                <input type="text" name="nama_peserta" class="form-control" value="<?= htmlspecialchars($data['nama_peserta']); ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($data['email']); ?>" required>
            </div>
            <div class="form-group">
                <label>No HP</label>
                <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($data['no_hp']); ?>" required>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" class="form-control" required><?= htmlspecialchars($data['alamat']); ?></textarea>
            </div>
            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="peserta.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
