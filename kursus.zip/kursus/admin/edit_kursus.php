<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil ID kursus dari GET
if (!isset($_GET['id'])) {
    echo "ID tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);

// Ambil data kursus berdasarkan ID
$stmt = $conn->prepare("SELECT * FROM kursus WHERE id_kursus = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    echo "Data kursus tidak ditemukan.";
    exit;
}

// Ambil data instruktur untuk dropdown
$instruktur_result = $conn->query("SELECT id_instruktur, nama_instruktur FROM instruktur");

// Proses update jika form disubmit
if (isset($_POST['update'])) {
    $id_kursus = intval($_POST['id_kursus']);
    $nama = $_POST['nama_kursus'];
    $harga = floatval($_POST['harga']);
    $durasi = $_POST['durasi'];
    $id_instruktur = intval($_POST['id_instruktur']);

    $stmt = $conn->prepare("CALL update_kursus(?, ?, ?, ?, ?)");
    $stmt->bind_param("isdsi", $id_kursus, $nama, $harga, $durasi, $id_instruktur);

    if ($stmt->execute()) {
        echo "<script>alert('Kursus berhasil diperbarui'); window.location='kursus.php';</script>";
        exit;
    } else {
        echo "Gagal memperbarui data: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Kursus</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ffe6f0;
        }
        .btn-pink {
            background-color: #ff69b4;
            color: white;
        }
        .btn-pink:hover {
            background-color: #ff4da6;
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: #fff0f5;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h3 class="mb-4">Edit Data Kursus</h3>
        <form method="POST">
            <input type="hidden" name="id_kursus" value="<?php echo $id; ?>">

            <div class="form-group">
                <label>Nama Kursus</label>
                <input type="text" name="nama_kursus" class="form-control" value="<?php echo htmlspecialchars($data['nama_kursus']); ?>" required>
            </div>

            <div class="form-group">
                <label>Harga</label>
                <input type="number" step="0.01" name="harga" class="form-control" value="<?php echo htmlspecialchars($data['harga']); ?>" required>
            </div>

            <div class="form-group">
                <label>Durasi</label>
                <select name="durasi" class="form-control" required>
                    <?php
                    $durasi_options = ["1 Bulan", "3 Bulan", "6 Bulan", "12 Bulan"];
                    foreach ($durasi_options as $option) {
                        $selected = ($option == $data['durasi']) ? 'selected' : '';
                        echo "<option value='$option' $selected>$option</option>";
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Instruktur</label>
                <select name="id_instruktur" class="form-control" required>
                    <option value="">-- Pilih Instruktur --</option>
                    <?php
                    while ($instruktur = $instruktur_result->fetch_assoc()) {
                        $selected = ($instruktur['id_instruktur'] == $data['id_instruktur']) ? 'selected' : '';
                        echo "<option value='{$instruktur['id_instruktur']}' $selected>" . htmlspecialchars($instruktur['nama_instruktur']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <button type="submit" name="update" class="btn btn-pink">Simpan Perubahan</button>
            <a href="kursus.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
