<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Periksa apakah ada parameter id yang dikirim
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // aman dari SQL Injection sederhana

    // Query hapus data pembayaran berdasarkan id_pembayaran
    $query = "DELETE FROM pembayaran WHERE id_pembayaran = $id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Redirect kembali ke halaman pembayaran setelah berhasil hapus
        header("Location: pembayaran.php");
        exit;
    } else {
        echo "Error saat menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID pembayaran tidak ditemukan.";
}
?>
