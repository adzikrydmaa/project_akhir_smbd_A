<?php
$conn = new mysqli("localhost", "root", "", "kursusku");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // 1. Hapus sertifikat berdasarkan id_pendaftaran yang terkait dengan kursus
    $query1 = "
        DELETE FROM sertifikat 
        WHERE id_pendaftaran IN (
            SELECT id_pendaftaran FROM pendaftaran WHERE id_kursus = ?
        )";
    $stmt1 = $conn->prepare($query1);
    $stmt1->bind_param("i", $id);
    $stmt1->execute();
    $stmt1->close();

    // 2. Hapus pembayaran berdasarkan id_pendaftaran yang terkait dengan kursus
    $query2 = "
        DELETE FROM pembayaran 
        WHERE id_pendaftaran IN (
            SELECT id_pendaftaran FROM pendaftaran WHERE id_kursus = ?
        )";
    $stmt2 = $conn->prepare($query2);
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $stmt2->close();

    // 3. Hapus pendaftaran terkait kursus
    $query3 = "DELETE FROM pendaftaran WHERE id_kursus = ?";
    $stmt3 = $conn->prepare($query3);
    $stmt3->bind_param("i", $id);
    $stmt3->execute();
    $stmt3->close();

    // 4. Hapus kursus
    $query4 = "DELETE FROM kursus WHERE id_kursus = ?";
    $stmt4 = $conn->prepare($query4);
    $stmt4->bind_param("i", $id);
    if ($stmt4->execute()) {
        header("Location: kursus.php?msg=hapus_sukses");
    } else {
        echo "Gagal menghapus kursus: " . $conn->error;
    }
    $stmt4->close();

} else {
    echo "ID tidak ditemukan.";
}

$conn->close();
?>
