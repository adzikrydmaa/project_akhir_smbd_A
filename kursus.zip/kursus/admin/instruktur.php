<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_instruktur'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $keahlian = $_POST['keahlian'];

    $query = "INSERT INTO instruktur (nama_instruktur, email, no_hp, keahlian)
              VALUES ('$nama', '$email', '$no_hp', '$keahlian')";
    mysqli_query($conn, $query);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Cek apakah hanya menampilkan daftar saja
$hanyaDaftar = isset($_GET['view']) && $_GET['view'] === 'daftar';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Instruktur</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <style>
    .btn-pink {
      background-color:rgb(66, 39, 109);
      color: white;
      border: none;
    }
    .btn-pink:hover {
      background-color: rgb(66, 39, 109);
    }
    .nav-sidebar .nav-link.active {
      background-color: rgb(66, 39, 109) !important;
      color: white !important;
    }
    .nav-sidebar .nav-item:hover > .nav-link {
      background-color:rgb(66, 39, 109);
      color: #fff;
    }
    .sidebar::-webkit-scrollbar-thumb {
      background-color: rgb(66, 39, 109);
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color:rgb(66, 39, 109);"></i></a>
      </li>
    </ul>
  </nav>

  <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color: white; font-weight: bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
          <li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="nav-icon fas fa-tachometer-alt" style="color: white;"></i><p>Dashboard</p></a></li>
          <li class="nav-item"><a href="instruktur.php" class="nav-link active"><i class="nav-icon fas fa-user-tie" style="color: white;"></i><p>Instruktur</p></a></li>
          <li class="nav-item"><a href="peserta.php" class="nav-link"><i class="nav-icon fas fa-users" style="color: white;"></i><p>Peserta</p></a></li>
          <li class="nav-item"><a href="kursus.php" class="nav-link"><i class="nav-icon fas fa-book-open" style="color: white;"></i><p>Kursus</p></a></li>
          <li class="nav-item"><a href="pendaftaran.php" class="nav-link"><i class="nav-icon fas fa-file-signature" style="color: white;"></i><p>Pendaftaran</p></a></li>
          <li class="nav-item"><a href="pembayaran.php" class="nav-link"><i class="nav-icon fas fa-money-bill-wave" style="color: white;"></i><p>Pembayaran</p></a></li>
          <li class="nav-item"><a href="sertifikat.php" class="nav-link"><i class="nav-icon fas fa-certificate" style="color: white;"></i><p>Sertifikat</p></a></li>
          <li class="nav-item"><a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fas fa-sign-out-alt mr-2"></i><p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <h1 class="m-0 text-dark">Manajemen Instruktur</h1>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">
        <?php if (!$hanyaDaftar): ?>
        <!-- Form Tambah Instruktur -->
        <div class="card" style="border-top: 3px solid rgb(66, 39, 109)">
          <div class="card-header" style="background-color:rgb(66, 39, 109);">
            <h3 class="card-title text-white">Tambah Instruktur</h3>
          </div>
          <div class="card-body">
            <form method="POST">
              <div class="row">
                <div class="col-md-3"><label>Nama Instruktur</label><input type="text" name="nama_instruktur" class="form-control" required></div>
                <div class="col-md-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
                <div class="col-md-3"><label>No HP</label><input type="text" name="no_hp" class="form-control" required></div>
                <div class="col-md-3"><label>Keahlian</label><input type="text" name="keahlian" class="form-control" required></div>
              </div>
              <div class="mt-3">
                <button type="submit" name="simpan" class="btn btn-pink"><i class="fas fa-plus"></i> Simpan</button>
              </div>
            </form>
          </div>
        </div>
        <?php endif; ?>

        <!-- Daftar Instruktur -->
        <div class="card" style="border-top: 3px solid rgb(178, 236, 178)">
          <div class="card-header" style="background-color:rgb(66, 39, 109);">
            <h3 class="card-title text-white">Daftar Instruktur</h3>
          </div>
          <div class="card-body">
            <table class="table table-bordered table-striped">
              <thead style="background-color: rgb(66, 39, 109); color: white;">
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>No HP</th>
                  <th>Keahlian</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                $result = mysqli_query($conn, "CALL get_instruktur()");
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>
                          <td>{$no}</td>
                          <td>{$row['nama_instruktur']}</td>
                          <td>{$row['email']}</td>
                          <td>{$row['no_hp']}</td>
                          <td>{$row['keahlian']}</td>
                          <td>
                            <a href='edit_instruktur.php?id={$row['id_instruktur']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='hapus_instruktur.php?id={$row['id_instruktur']}' onclick='return confirm(\"Yakin hapus?\")' class='btn btn-danger btn-sm'>Hapus</a>
                          </td>
                        </tr>";
                  $no++;
                }
                mysqli_next_result($conn); // Reset result set jika ingin query lain
                ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="main-footer text-center">
    <strong>© 2025 Sistem Kursus</strong>
  </footer>
</div>

<!-- Script -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
