<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Periksa apakah ada parameter id yang dikirim
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query hapus data
    $query = "DELETE FROM instruktur WHERE id_instruktur = $id";
    $result = mysqli_query($conn, $query);

    // Redirect kembali ke halaman instruktur
    header("Location: instruktur.php");
    exit;
} else {
    echo "ID tidak ditemukan.";
}
?>