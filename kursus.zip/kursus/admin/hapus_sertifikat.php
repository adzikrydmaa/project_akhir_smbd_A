<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Periksa apakah ada parameter id yang dikirim
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // untuk keamanan

    // Jika ada file sertifikat di database, hapus file fisiknya juga (opsional)
    $file_query = "SELECT file_sertifikat FROM sertifikat WHERE id_sertifikat = $id";
    $file_result = mysqli_query($conn, $file_query);
    if ($file_result && mysqli_num_rows($file_result) > 0) {
        $row = mysqli_fetch_assoc($file_result);
        $file_path = $row['file_sertifikat'];
        if ($file_path && file_exists($file_path)) {
            unlink($file_path); // hapus file fisik
        }
    }

    // Query hapus data sertifikat
    $query = "DELETE FROM sertifikat WHERE id_sertifikat = $id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Redirect kembali ke halaman sertifikat
        header("Location: sertifikat.php");
        exit;
    } else {
        echo "Error saat menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan.";
}
?>
