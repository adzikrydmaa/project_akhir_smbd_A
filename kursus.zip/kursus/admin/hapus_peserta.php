<?php
$conn = new mysqli("localhost", "root", "", "kursusku");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // 1. Hapus sertifikat yang terkait dengan pendaftaran milik peserta ini
    $query1 = "
        DELETE FROM sertifikat 
        WHERE id_pendaftaran IN (
            SELECT id_pendaftaran FROM pendaftaran WHERE id_peserta = ?
        )";
    $stmt1 = $conn->prepare($query1);
    $stmt1->bind_param("i", $id);
    $stmt1->execute();
    $stmt1->close();

    // 2. Hapus pembayaran
    $query2 = "
        DELETE FROM pembayaran 
        WHERE id_pendaftaran IN (
            SELECT id_pendaftaran FROM pendaftaran WHERE id_peserta = ?
        )";
    $stmt2 = $conn->prepare($query2);
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $stmt2->close();

    // 3. Hapus pendaftaran
    $query3 = "DELETE FROM pendaftaran WHERE id_peserta = ?";
    $stmt3 = $conn->prepare($query3);
    $stmt3->bind_param("i", $id);
    $stmt3->execute();
    $stmt3->close();

    // 4. Hapus peserta
    $query4 = "DELETE FROM peserta WHERE id_peserta = ?";
    $stmt4 = $conn->prepare($query4);
    $stmt4->bind_param("i", $id);
    if ($stmt4->execute()) {
        header("Location: peserta.php?msg=hapus_sukses");
    } else {
        echo "Gagal menghapus peserta: " . $conn->error;
    }
    $stmt4->close();
} else {
    echo "ID tidak ditemukan.";
}

$conn->close();
?>
