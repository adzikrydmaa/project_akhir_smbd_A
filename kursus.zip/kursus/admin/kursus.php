<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$instruktur_result = mysqli_query($conn, "SELECT * FROM instruktur");

if (isset($_POST['simpan'])) {
    $nama_kursus = $_POST['nama_kursus']; 
    $harga = $_POST['harga'];
    $durasi = $_POST['durasi'];
    $id_instruktur = $_POST['id_instruktur'];

    if ($harga < 0) {
        echo "<script>alert('Harga tidak boleh minus!'); window.location.href='".$_SERVER['PHP_SELF']."';</script>";
        exit;
    }
    
    $query = "INSERT INTO kursus (nama_kursus, harga, durasi, id_instruktur)
              VALUES ('$nama_kursus', '$harga', '$durasi', '$id_instruktur')";
    
    if (!mysqli_query($conn, $query)) {
        echo "Error: " . mysqli_error($conn);
    } else {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Kursus</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

  <style>
    .btn-pink {
      background-color: rgb(66, 39, 109);
      color: white;
      border: none;
    }
    .btn-pink:hover {
      background-color: rgb(66, 39, 109);
    }
    .nav-sidebar .nav-link.active {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .nav-sidebar .nav-item:hover > .nav-link {
      background-color: rgb(66, 39, 109);
      color: white !important;
    }
    .sidebar::-webkit-scrollbar-thumb {
      background-color: rgb(66, 39, 109);
    }
    .input-group-text {
      background-color: rgb(66, 39, 109);
      color: white;
      border: none;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color:rgb(66, 39, 109);"></i></a>
      </li>
    </ul>
  </nav>

  <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color: #fff; font-weight: bold;">SISTEM KURSUS</span>
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt" style="color: white;"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="instruktur.php" class="nav-link">
              <i class="nav-icon fas fa-user-tie" style="color: white;"></i>
              <p>Instruktur</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="peserta.php" class="nav-link">
              <i class="nav-icon fas fa-users" style="color: white;"></i>
              <p>Peserta</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="kursus.php" class="nav-link active">
              <i class="nav-icon fas fa-book-open" style="color: white;"></i>
              <p>Kursus</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pendaftaran.php" class="nav-link">
              <i class="nav-icon fas fa-file-signature" style="color: white;"></i>
              <p>Pendaftaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pembayaran.php" class="nav-link">
              <i class="nav-icon fas fa-money-bill-wave" style="color: white;"></i>
              <p>Pembayaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="sertifikat.php" class="nav-link">
              <i class="nav-icon fas fa-certificate" style="color: white;"></i>
              <p>Sertifikat</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')">
              <i class="fas fa-sign-out-alt mr-2"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- Content Wrapper -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <h1 class="m-0 text-dark">Manajemen Kursus</h1>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">
        <!-- Form Tambah -->
        <div class="card" style="border-top: 3px solid rgb(66, 39, 109);">
          <div class="card-header" style="background-color:rgb(66, 39, 109);">
            <h3 class="card-title text-white">Tambah Kursus</h3>
          </div>
          <div class="card-body">
            <form method="POST" onsubmit="return validateForm()">
              <div class="row">
                <div class="col-md-3">
                  <label>Nama Kursus</label>
                  <input
                    type="text"
                    name="nama_kursus"
                    class="form-control"
                    placeholder="Masukkan nama kursus"
                    required
                  />
                </div>
                <div class="col-md-3">
                  <label>Harga</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Rp</span>
                    </div>
                    <input
                      type="number"
                      name="harga"
                      id="harga"
                      class="form-control"
                      min="0"
                      step="1000"
                      required
                      placeholder="0"
                    />
                  </div>
                </div>
                <div class="col-md-3">
                  <label>Durasi</label>
                  <select name="durasi" class="form-control" required>
                    <option value="">-- Pilih Durasi --</option>
                    <option value="1 bulan">1 bulan</option>
                    <option value="3 bulan">3 bulan</option>
                    <option value="6 bulan">6 bulan</option>
                    <option value="12 bulan">12 bulan</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <label>Instruktur</label>
                  <select name="id_instruktur" class="form-control" required>
                    <option value="">-- Pilih Instruktur --</option>
                    <?php while ($instruktur = mysqli_fetch_assoc($instruktur_result)) : ?>
                      <option value="<?= $instruktur['id_instruktur']; ?>">
                        <?= htmlspecialchars($instruktur['nama_instruktur']); ?>
                      </option>
                    <?php endwhile; ?>
                  </select>
                </div>
              </div>
              <div class="mt-3">
                <button type="submit" name="simpan" class="btn btn-pink">
                  <i class="fas fa-plus"></i> Simpan
                </button>
              </div>
            </form>
          </div>
        </div>

        <!-- Tabel -->
        <div class="card border-top border-pink">
          <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
            <h3 class="card-title text-white">Daftar Kursus</h3>
          </div>
          <div class="card-body">
            <table class="table table-bordered table-striped">
              <thead style="background-color: rgb(66, 39, 109); color: white;">
                <tr>
                  <th>No</th>
                  <th>Nama Kursus</th>
                  <th>Harga</th>
                  <th>Durasi</th>
                  <th>Instruktur</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                $result = mysqli_query($conn, "SELECT k.*, i.nama_instruktur FROM kursus k LEFT JOIN instruktur i ON k.id_instruktur = i.id_instruktur");
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>
                          <td>{$no}</td>
                          <td>" . htmlspecialchars($row['nama_kursus']) . "</td>
                          <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                          <td>" . htmlspecialchars($row['durasi']) . "</td>
                          <td>" . htmlspecialchars($row['nama_instruktur']) . "</td>
                          <td>
                            <a href='edit_kursus.php?id={$row['id_kursus']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='hapus_kursus.php?id={$row['id_kursus']}' onclick='return confirm(\"Yakin hapus?\")' class='btn btn-danger btn-sm'>Hapus</a>
                          </td>
                        </tr>";
                  $no++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="main-footer text-center">
    <strong>© 2025 Sistem Kursus</strong>
  </footer>
</div>

<!-- Script -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
  function validateForm() {
    const harga = document.getElementById('harga').value;
    if (harga < 0) {
      alert('Harga tidak boleh minus!');
      return false;
    }
    return true;
  }
</script>
</body>
</html>
