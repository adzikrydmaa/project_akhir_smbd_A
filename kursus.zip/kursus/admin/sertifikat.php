<?php
// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kursusku";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Proses simpan sertifikat jika form disubmit
if (isset($_POST['simpan'])) {
    $id_pendaftaran = intval($_POST['id_pendaftaran']);
    $nomor_sertifikat = $_POST['nomor_sertifikat'];
    $tanggal_terbit = $_POST['tanggal_terbit'];
    
    // Upload file sertifikat (misal PDF)
    $file_sertifikat = null;
    if (isset($_FILES['file_sertifikat']) && $_FILES['file_sertifikat']['error'] == 0) {
        $target_dir = "uploads/sertifikat/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

        $filename = basename($_FILES["file_sertifikat"]["name"]);
        $target_file = $target_dir . time() . "_" . $filename; // tambahkan timestamp agar unik

        // Cek ekstensi file (boleh ditambah validasi lebih ketat)
        $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array($fileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["file_sertifikat"]["tmp_name"], $target_file)) {
                $file_sertifikat = $target_file;
            } else {
                echo "<script>alert('Gagal upload file sertifikat');</script>";
            }
        } else {
            echo "<script>alert('Format file tidak diperbolehkan');</script>";
        }
    }

    // Escape input untuk keamanan
    $id_pendaftaran = mysqli_real_escape_string($conn, $id_pendaftaran);
    $nomor_sertifikat = mysqli_real_escape_string($conn, $nomor_sertifikat);
    $tanggal_terbit = mysqli_real_escape_string($conn, $tanggal_terbit);
    $file_sertifikat_esc = mysqli_real_escape_string($conn, $file_sertifikat);

    $query = "INSERT INTO sertifikat (id_pendaftaran, nomor_sertifikat, tanggal_terbit, file_sertifikat)
              VALUES ($id_pendaftaran, '$nomor_sertifikat', '$tanggal_terbit', '$file_sertifikat_esc')";

    if (mysqli_query($conn, $query)) {
        header("Location: sertifikat.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Ambil data pendaftaran untuk dropdown (tampilkan id dan nama peserta)
$pendaftaran_query = "SELECT p.id_pendaftaran, ps.nama_peserta 
                      FROM pendaftaran p 
                      JOIN peserta ps ON p.id_peserta = ps.id_peserta";
$pendaftaran_result = mysqli_query($conn, $pendaftaran_query);

// Ambil semua sertifikat beserta data pendaftaran dan peserta
$sertifikat_query = "SELECT s.id_sertifikat, s.nomor_sertifikat, s.tanggal_terbit, s.file_sertifikat,
                     p.id_pendaftaran, ps.nama_peserta
                     FROM sertifikat s
                     JOIN pendaftaran p ON s.id_pendaftaran = p.id_pendaftaran
                     JOIN peserta ps ON p.id_peserta = ps.id_peserta
                     ORDER BY s.tanggal_terbit DESC";
$sertifikat_result = mysqli_query($conn, $sertifikat_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Pendaftaran Kursus</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- AdminLTE & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

  <style>
    :root {
      --pink-main: rgb(66, 39, 109);
      --pink-hover: rgb(55, 30, 90);
    }
    .btn-pink { background-color: rgb(66, 39, 109); color: #fff; border: none; }
    .btn-pink:hover { background-color: rgb(66, 39, 109); }
    .nav-sidebar .nav-link.active { background: rgb(66, 39, 109); color:#fff !important; }
    .nav-sidebar .nav-item:hover > .nav-link { background: rgb(66, 39, 109); color:#fff !important; }
    .sidebar::-webkit-scrollbar-thumb { background: rgb(66, 39, 109)); }
  </style>
</head>
<body class="hold-transition sidebar-mini">
  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars" style="color: rgb(66, 39, 109);"></i></a>
        </li>
      </ul>
    </nav>

    <!-- Sidebar -->
  <aside class="main-sidebar sidebar-dark-pink elevation-4" style="background-color:rgb(66, 39, 109);">
    <a href="#" class="brand-link text-center">
      <span style="color:#fff;font-weight:bold;">SISTEM KURSUS</span>
    </a>

    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt" style="color:#fff;"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item"><a href="instruktur.php" class="nav-link"><i class="nav-icon fas fa-user-tie" style="color:#fff;"></i><p>Instruktur</p></a></li>
          <li class="nav-item"><a href="peserta.php" class="nav-link"><i class="nav-icon fas fa-users" style="color:#fff;"></i><p>Peserta</p></a></li>
          <li class="nav-item"><a href="kursus.php" class="nav-link"><i class="nav-icon fas fa-book-open" style="color:#fff;"></i><p>Kursus</p></a></li>
          <li class="nav-item"><a href="pendaftaran.php" class="nav-link"><i class="nav-icon fas fa-file-signature" style="color:#fff;"></i><p>Pendaftaran</p></a></li>
          <li class="nav-item"><a href="pembayaran.php" class="nav-link"><i class="nav-icon fas fa-money-bill-wave" style="color:#fff;"></i><p>Pembayaran</p></a></li>
          <li class="nav-item"><a href="sertifikat.php" class="nav-link active"><i class="nav-icon fas fa-certificate" style="color:#fff;"></i><p>Sertifikat</p></a></li>
          <li class="nav-item"><a class="nav-link" href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fas fa-sign-out-alt mr-2"></i><p>Logout</p></a>
        </ul>
      </nav>
    </div>
  </aside>
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <h1 class="m-0 text-dark">Dashboard Kursus</h1>
      </div>
    </div>
      <div class="content">
        <div class="container-fluid">
          <div class="card border-top border-pink">
        <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
          <h3 class="card-title text-white">Tambah Sertifikat</h3>
            </div>
            <div class="card-body">
              <form method="POST" action="" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-md-4">
                    <label for="id_pendaftaran">ID Pendaftaran</label>
                    <select name="id_pendaftaran" id="id_pendaftaran" class="form-control" required>
                      <option value="">-- Pilih Pendaftaran --</option>
                      <?php while ($row = mysqli_fetch_assoc($pendaftaran_result)): ?>
                        <option value="<?= $row['id_pendaftaran'] ?>">
                          ID <?= $row['id_pendaftaran'] ?> - <?= htmlspecialchars($row['nama_peserta']) ?>
                        </option>
                      <?php endwhile; ?>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <label for="nomor_sertifikat">Nomor Sertifikat</label>
                    <input type="text" name="nomor_sertifikat" id="nomor_sertifikat" class="form-control" required />
                  </div>
                  <div class="col-md-4">
                    <label for="tanggal_terbit">Tanggal Terbit</label>
                    <input type="date" name="tanggal_terbit" id="tanggal_terbit" class="form-control" required />
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-6">
                    <label for="file_sertifikat">File Sertifikat (PDF/JPG/PNG)</label>
                    <input type="file" name="file_sertifikat" id="file_sertifikat" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required />
                  </div>
                </div>
                <div class="mt-3">
                  <button type="submit" name="simpan" class="btn btn-pink">Simpan</button>
                </div>
              </form>
            </div>
          </div>
          <div class="card border-top border-pink">
        <div class="card-header" style="background-color:rgb(66, 39, 109) ;">
          <h3 class="card-title text-white">Daftar Sertifikat</h3>
            </div>
            <div class="card-body table-responsive p-0" style="max-height: 400px;">
              <table class="table table-bordered table-striped table-hover text-nowrap">
                <thead style="background-color: rgb(66, 39, 109); color: white;">
                  <tr>
                    <th>No</th>
                    <th>ID Sertifikat</th>
                    <th>Nomor Sertifikat</th>
                    <th>Nama Peserta</th>
                    <th>ID Pendaftaran</th>
                    <th>Tanggal Terbit</th>
                    <th>File Sertifikat</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $no = 1;
                  while ($row = mysqli_fetch_assoc($sertifikat_result)):
                  ?>
                    <tr>
                      <td><?= $no ?></td>
                      <td><?= $row['id_sertifikat'] ?></td>
                      <td><?= htmlspecialchars($row['nomor_sertifikat']) ?></td>
                      <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                      <td><?= $row['id_pendaftaran'] ?></td>
                      <td><?= $row['tanggal_terbit'] ?></td>
                      <td>
                        <?php if ($row['file_sertifikat'] && file_exists($row['file_sertifikat'])): ?>
                          <a href="<?= htmlspecialchars($row['file_sertifikat']) ?>" target="_blank" class="btn btn-info btn-sm">
                            <i class="fas fa-file"></i> Lihat
                          </a>
                        <?php else: ?>
                          <span class="text-muted">Tidak ada file</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <a href="edit_sertifikat.php?id=<?= $row['id_sertifikat'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="hapus_sertifikat.php?id=<?= $row['id_sertifikat'] ?>" onclick="return confirm('Yakin hapus?')" class="btn btn-danger btn-sm">Hapus</a>
                      </td>
                    </tr>
                  <?php
                  $no++;
                  endwhile;
                  ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
      <strong>© 2025 Sistem Kursus</strong>
    </footer>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
